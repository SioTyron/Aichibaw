package main;

import views.FConnexionView;

public class main {
    public static void main(String[] args) {
        FConnexionView frame = new FConnexionView();
        frame.setVisible(true);
    }
}